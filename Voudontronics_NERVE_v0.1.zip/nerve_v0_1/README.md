# Voudontronics NERVE 0.1

**NERVE is an omnivorous transduction synthesizer for Linux.**

It is deliberately not a virtual analogue. Four **AFFERENTS** ingest arbitrary files and reinterpret them as signal/state/events. Four nontraditional generators — **AXON, GANGLION, BYTEWORM, KNOT** — form the other half of the organism. **GLIA** is a cellular-automaton modulation field, while **SYNAPSE** is a sparse routing system in which individual connections may use Sample+Hold.

This is the first playable architectural prototype, not the finished instrument.

## Current organs

- Four AFFERENT slots; each can load *any non-empty file*.
- Modes: `RAW BYTE`, `BITPLANE`, `TERRAIN`, `EVENT`, `AUDIO`.
- AUDIO understands uncompressed WAV directly; all other formats safely fall back to raw-byte interpretation.
- **AXON**: stochastic continuously mutating breakpoint waveform.
- **GANGLION**: stochastic impulse population exciting a resonant process.
- **BYTEWORM**: bitwise/integer computational generator.
- **KNOT**: nonlinear Hénon-like strange-attractor generator.
- **GLIA**: elementary cellular automaton used as global modulation weather.
- **SYNAPSE**: sparse node-to-node modulation matrix, with S&H living at connection level.
- Deterministic 64-bit patch seed plus BLAKE2b-256 identity for every ingested file.
- `SPACE` = new reproducible random state.
- `M` = mutation rather than replacement.
- `S` = record/stop and save WAV.
- Save/load `.nerve.json` patches; changed or missing food files are reported rather than silently substituted.
- Optional TouchMe support: CC90 controls **NERVE PRESSURE**.
- Optional generic gamepad support: trigger axes control pressure; main face buttons randomize/mutate.
- Offline renderer for machines where realtime audio is not yet configured.

## Install on Debian / Ubuntu / Ubuntu Studio

You will normally want PortAudio development/runtime packages available:

```bash
sudo apt install python3-venv libportaudio2 portaudio19-dev
```

Then:

```bash
cd nerve_v0_1
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -e .
nerve
```

For Playtronica TouchMe + gamepad support:

```bash
pip install -e '.[controllers]'
```

If Linux denies access to `/dev/input/event*`, add your user to the appropriate input group or install a suitable udev rule rather than running NERVE as root.

## Crostini / conservative audio launch

NERVE defaults to 48 kHz and a 1024-frame block because that is a useful conservative starting point for the Chromebook/Crostini environment:

```bash
nerve --sample-rate 48000 --block-size 1024
```

## Feed the machine

Click or drag any file onto an AFFERENT's **DROP / LOAD ANY FILE** button. Try images, text, archives, executables, old sample-disk binaries, ROM-like data, or WAV audio.

The file is **never executed**. NERVE only reads it as bytes (and, where supported, as a known media form).

## Offline test

No GUI and no audio device are needed:

```bash
nerve-render --seconds 12 --seed "KANNUS-NIGHT-001" --out test.wav
```

Or feed arbitrary files:

```bash
nerve-render --seconds 20 --feed picture.png --feed strange.bin --feed poem.txt --out digestion.wav
```

## Design rule

Python owns UI, file interpretation, patch logic, mapping and prototyping. When profiling shows the DSP hot path needs it, the mathematical/audio core moves to C++ behind a narrow binding. **Python code must never be called from a future C++ realtime audio callback.**

## Next likely layer (0.2)

1. Proper editable SYNAPSE matrix UI, including per-connection operation: `CONTINUOUS`, `S&H`, `XOR/MASK`, `GATE`, `CLOCK`, `EXCITE`, `INDEX`, `WARP`.
2. Specialized TEXT and IMAGE analyzers layered *above* the universal raw-byte system.
3. AFFERENT cryptographic identity + portable patch relinking.
4. Better multichannel/spatial topology.
5. C++ benchmark target for GANGLION/KNOT/SYNAPSE before moving code prematurely.
6. Carla/PipeWire JACK routing profile for external native plugins and yabridge-hosted Windows plugins.

Future candidates intentionally preserved: PULSAR, SOMA, RATIONAL, MORPHOGEN, SHIFT and graph-walking variants of SYNAPSE.
