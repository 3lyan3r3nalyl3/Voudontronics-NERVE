import numpy as np

from nerve.engine import NerveEngine


def test_engine_block_is_finite_and_stereo():
    e = NerveEngine(sample_rate=48000, block_size=256, seed="test")
    y = e.process(256)
    assert y.shape == (256, 2)
    assert y.dtype == np.float32
    assert np.all(np.isfinite(y))
    assert np.max(np.abs(y)) <= 1.0


def test_randomize_is_reproducible_for_parameters():
    a = NerveEngine(seed="a")
    b = NerveEngine(seed="b")
    a.randomize("same")
    b.randomize("same")
    assert a.glia.rule == b.glia.rule
    assert a.generators.byteworm.formula == b.generators.byteworm.formula
    assert np.array_equal(a.synapse.weights, b.synapse.weights)


def test_patch_roundtrip(tmp_path):
    food = tmp_path / "food.bin"
    food.write_bytes(bytes(range(64)) * 32)
    patch = tmp_path / "x.nerve.json"
    a = NerveEngine(seed="roundtrip")
    a.afferents.slots[0].load(food)
    a.randomize("roundtrip-state")
    a.save_patch(patch)
    b = NerveEngine(seed="other")
    warnings = b.load_patch(patch)
    assert warnings == []
    assert a.seed == b.seed
    assert a.glia.rule == b.glia.rule
    assert np.array_equal(a.synapse.weights, b.synapse.weights)
    assert b.afferents.slots[0].content_hash == a.afferents.slots[0].content_hash
