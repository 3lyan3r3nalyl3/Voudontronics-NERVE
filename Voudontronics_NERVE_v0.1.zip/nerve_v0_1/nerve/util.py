from __future__ import annotations

import hashlib
from pathlib import Path

import numpy as np


def stable_seed(value: str | bytes | int) -> int:
    """Return a stable unsigned 64-bit seed from arbitrary input."""
    if isinstance(value, int):
        return value & ((1 << 64) - 1)
    if isinstance(value, str):
        value = value.encode("utf-8", "surrogatepass")
    return int.from_bytes(hashlib.blake2b(value, digest_size=8).digest(), "little")


def file_hash(path: str | Path) -> str:
    """Return a BLAKE2b-256 content identity without loading the whole file."""
    h = hashlib.blake2b(digest_size=32)
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def file_seed(path: str | Path) -> int:
    return stable_seed(bytes.fromhex(file_hash(path)))


def bipolar_u8(values: np.ndarray) -> np.ndarray:
    return values.astype(np.float32) * (2.0 / 255.0) - 1.0


def softclip(x: np.ndarray, drive: float = 1.0) -> np.ndarray:
    return np.tanh(x * np.float32(drive)).astype(np.float32, copy=False)
