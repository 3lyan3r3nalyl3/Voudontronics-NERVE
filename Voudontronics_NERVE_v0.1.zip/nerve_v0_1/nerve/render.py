from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np

from .engine import NerveEngine, write_wav


def main(argv=None):
    p = argparse.ArgumentParser(description="Render NERVE without a realtime audio device")
    p.add_argument("--seconds", type=float, default=8.0)
    p.add_argument("--out", default="nerve_render.wav")
    p.add_argument("--sample-rate", type=int, default=48000)
    p.add_argument("--block-size", type=int, default=1024)
    p.add_argument("--seed", default="NERVE-001")
    p.add_argument("--feed", action="append", default=[], help="File to feed into AFF1..AFF4; may be repeated")
    args = p.parse_args(argv)

    engine = NerveEngine(args.sample_rate, args.block_size, args.seed)
    for i, path in enumerate(args.feed[:4]):
        engine.afferents.slots[i].load(path)
    engine.randomize(args.seed)
    total = int(args.seconds * args.sample_rate)
    blocks = []
    done = 0
    while done < total:
        n = min(args.block_size, total - done)
        blocks.append(engine.process(n))
        done += n
    audio = np.concatenate(blocks, axis=0)
    out = write_wav(Path(args.out), audio, args.sample_rate)
    print(out)


if __name__ == "__main__":
    main()
