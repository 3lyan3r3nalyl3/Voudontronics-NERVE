from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import sounddevice as sd
from PySide6 import QtCore, QtGui, QtWidgets

from .afferent import AfferentMode
from .controllers import ControllerHub
from .engine import NerveEngine


QSS = """
QWidget { background: #050706; color: #93ff9d; font-family: DejaVu Sans Mono; }
QGroupBox { border: 1px solid #344b3a; margin-top: 10px; padding-top: 8px; font-weight: 700; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: #b388ff; }
QPushButton { background: #101412; border: 1px solid #7354a8; padding: 7px; }
QPushButton:hover { border: 1px solid #b388ff; }
QComboBox, QSlider { background: #101412; }
QLabel#brand { font-size: 23px; font-weight: 900; color: #b388ff; }
QLabel#seed { color: #81ff91; }
"""


class DropButton(QtWidgets.QPushButton):
    fileDropped = QtCore.Signal(str)

    def __init__(self, text: str):
        super().__init__(text)
        self.setAcceptDrops(True)

    def dragEnterEvent(self, event: QtGui.QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QtGui.QDropEvent):
        urls = event.mimeData().urls()
        if urls and urls[0].isLocalFile():
            self.fileDropped.emit(urls[0].toLocalFile())
            event.acceptProposedAction()


class NerveWindow(QtWidgets.QWidget):
    def __init__(self, engine: NerveEngine):
        super().__init__()
        self.engine = engine
        self.stream = None
        self.controller_hub = ControllerHub(engine)
        self.recording = False
        self.setWindowTitle("Voudontronics NERVE 0.1")
        self.resize(1240, 760)
        self.setStyleSheet(QSS)
        self._build()
        self._start_audio()
        self.controller_hub.start()
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self._tick)
        self.timer.start(250)

    def _build(self):
        root = QtWidgets.QVBoxLayout(self)
        top = QtWidgets.QHBoxLayout()
        brand = QtWidgets.QLabel("VOUDONTRONICS  /  NERVE")
        brand.setObjectName("brand")
        self.seed_label = QtWidgets.QLabel()
        self.seed_label.setObjectName("seed")
        random_btn = QtWidgets.QPushButton("RANDOMIZE  [SPACE]")
        random_btn.clicked.connect(self.randomize)
        mutate_btn = QtWidgets.QPushButton("MUTATE  [M]")
        mutate_btn.clicked.connect(self.mutate)
        save_btn = QtWidgets.QPushButton("SAVE PATCH")
        save_btn.clicked.connect(self.save_patch)
        load_btn = QtWidgets.QPushButton("LOAD PATCH")
        load_btn.clicked.connect(self.load_patch)
        self.record_btn = QtWidgets.QPushButton("RECORD  [S]")
        self.record_btn.clicked.connect(self.toggle_record)
        top.addWidget(brand); top.addStretch(1); top.addWidget(self.seed_label); top.addWidget(random_btn); top.addWidget(mutate_btn); top.addWidget(save_btn); top.addWidget(load_btn); top.addWidget(self.record_btn)
        root.addLayout(top)

        middle = QtWidgets.QHBoxLayout()
        aff_box = QtWidgets.QGroupBox("AFFERENTS / FOUR MOUTHS")
        aff_layout = QtWidgets.QGridLayout(aff_box)
        self.aff_widgets = []
        for i, slot in enumerate(self.engine.afferents.slots):
            grp = QtWidgets.QGroupBox(f"AFF{i+1}")
            lay = QtWidgets.QVBoxLayout(grp)
            load = DropButton("DROP / LOAD ANY FILE")
            load.clicked.connect(lambda _=False, idx=i: self.choose_file(idx))
            load.fileDropped.connect(lambda p, idx=i: self.load_file(idx, p))
            name = QtWidgets.QLabel(slot.label)
            name.setWordWrap(True)
            mode = QtWidgets.QComboBox()
            mode.addItems([m.value for m in AfferentMode])
            mode.currentTextChanged.connect(lambda text, idx=i: self.set_aff_mode(idx, text))
            gain = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal); gain.setRange(0, 100); gain.setValue(int(slot.gain*100))
            gain.valueChanged.connect(lambda v, idx=i: self.set_aff_gain(idx, v / 100.0))
            lay.addWidget(load); lay.addWidget(name); lay.addWidget(mode); lay.addWidget(QtWidgets.QLabel("INGEST GAIN")); lay.addWidget(gain)
            aff_layout.addWidget(grp, i // 2, i % 2)
            self.aff_widgets.append((name, mode, gain))
        middle.addWidget(aff_box, 3)

        gen_box = QtWidgets.QGroupBox("GENERATORS / FOUR ORGANS")
        gen_layout = QtWidgets.QVBoxLayout(gen_box)
        descriptions = [
            ("AXON", "stochastic wandering waveform / probability as shape"),
            ("GANGLION", "spike populations / resonant point process"),
            ("BYTEWORM", "integer logic / bitwise computational organism"),
            ("KNOT", "nonlinear map / strange-attractor signal"),
        ]
        for title, desc in descriptions:
            grp = QtWidgets.QGroupBox(title)
            lay = QtWidgets.QVBoxLayout(grp)
            label = QtWidgets.QLabel(desc); label.setWordWrap(True)
            lay.addWidget(label)
            gen_layout.addWidget(grp)
        gen_layout.addStretch(1)
        middle.addWidget(gen_box, 2)

        nerve_box = QtWidgets.QGroupBox("GLIA / SYNAPSE")
        nerve_layout = QtWidgets.QVBoxLayout(nerve_box)
        self.glia_label = QtWidgets.QLabel()
        self.syn_label = QtWidgets.QLabel()
        self.pressure_label = QtWidgets.QLabel()
        nerve_layout.addWidget(QtWidgets.QLabel("GLIA is the cellular modulation weather.\nSYNAPSE is the sparse inter-node nervous system.\nSample+Hold belongs to individual synapses."))
        nerve_layout.addSpacing(12)
        nerve_layout.addWidget(self.glia_label)
        nerve_layout.addWidget(self.syn_label)
        nerve_layout.addWidget(self.pressure_label)
        nerve_layout.addStretch(1)
        middle.addWidget(nerve_box, 2)
        root.addLayout(middle, 1)

        self.status = QtWidgets.QLabel("INITIALIZING NERVOUS SYSTEM…")
        root.addWidget(self.status)
        self._refresh()

    def _start_audio(self):
        def callback(outdata, frames, time_info, status):
            if status:
                pass
            block = self.engine.process(frames)
            outdata[:] = block
        try:
            self.stream = sd.OutputStream(samplerate=self.engine.sample_rate, blocksize=self.engine.block_size, channels=2, dtype="float32", callback=callback)
            self.stream.start()
            self.status.setText(f"AUDIO ACTIVE / {self.engine.sample_rate} Hz / block {self.engine.block_size}")
        except Exception as exc:
            self.stream = None
            self.status.setText(f"GUI ACTIVE / AUDIO DEVICE ERROR: {exc} / use nerve-render for offline testing")

    def choose_file(self, idx: int):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, f"Feed AFF{idx+1}")
        if path:
            self.load_file(idx, path)

    def load_file(self, idx: int, path: str):
        try:
            self.engine.afferents.slots[idx].load(path)
            self.aff_widgets[idx][0].setText(Path(path).name)
            self.status.setText(f"AFF{idx+1} DIGESTING: {path}")
        except Exception as exc:
            self.status.setText(f"DIGESTION ERROR: {exc}")

    def set_aff_mode(self, idx: int, text: str):
        self.engine.afferents.slots[idx].mode = AfferentMode(text)

    def set_aff_gain(self, idx: int, value: float):
        self.engine.afferents.slots[idx].gain = value

    @QtCore.Slot()
    def randomize(self):
        self.engine.randomize()
        self._refresh()
        self.status.setText("NEW REPRODUCIBLE NERVOUS SYSTEM GENERATED")

    @QtCore.Slot()
    def mutate(self):
        self.engine.mutate()
        self._refresh()
        self.status.setText("LOCAL MUTATION APPLIED")

    @QtCore.Slot()
    def save_patch(self):
        path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save NERVE patch", "nerve_patch.nerve.json", "NERVE patch (*.nerve.json);;JSON (*.json)")
        if path:
            self.engine.save_patch(path)
            self.status.setText(f"PATCH SAVED: {path}")

    @QtCore.Slot()
    def load_patch(self):
        path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "Load NERVE patch", "", "NERVE patch (*.nerve.json *.json);;All files (*)")
        if path:
            try:
                warnings = self.engine.load_patch(path)
                self._refresh()
                for i, slot in enumerate(self.engine.afferents.slots):
                    self.aff_widgets[i][0].setText(slot.label)
                self.status.setText("PATCH LOADED" + ((" / " + " / ".join(warnings)) if warnings else ""))
            except Exception as exc:
                self.status.setText(f"PATCH ERROR: {exc}")

    @QtCore.Slot()
    def toggle_record(self):
        if not self.recording:
            self.engine.start_recording(); self.recording = True
            self.record_btn.setText("STOP + SAVE  [S]")
            self.status.setText("RECORDING NERVE OUTPUT")
        else:
            path, _ = QtWidgets.QFileDialog.getSaveFileName(self, "Save NERVE recording", "nerve_capture.wav", "WAV (*.wav)")
            if path:
                self.engine.stop_recording(path)
                self.status.setText(f"SAVED: {path}")
            else:
                self.engine._recording = False
            self.recording = False; self.record_btn.setText("RECORD  [S]")

    def _refresh(self):
        self.seed_label.setText(f"SEED {self.engine.seed:016X}")
        self.glia_label.setText(f"GLIA RULE {self.engine.glia.rule:03d}  /  {self.engine.glia.hz:.2f} Hz")
        active = int(np.count_nonzero(self.engine.synapse.weights))
        held = int(np.count_nonzero(self.engine.synapse.hold_samples))
        self.syn_label.setText(f"SYNAPSES {active}  /  S&H {held}  /  DEPTH {self.engine.synapse.depth:.2f}")
        self.pressure_label.setText(f"NERVE PRESSURE {self.engine.pressure:.2f}")
        for i, slot in enumerate(self.engine.afferents.slots):
            _, combo, slider = self.aff_widgets[i]
            combo.blockSignals(True); combo.setCurrentText(slot.mode.value); combo.blockSignals(False)
            slider.blockSignals(True); slider.setValue(int(slot.gain*100)); slider.blockSignals(False)

    def _tick(self):
        self._refresh()
        if self.controller_hub.messages:
            self.status.setText(" / ".join(self.controller_hub.messages[-3:]))

    def keyPressEvent(self, event: QtGui.QKeyEvent):
        if event.key() == QtCore.Qt.Key.Key_Space:
            self.randomize(); event.accept(); return
        if event.key() == QtCore.Qt.Key.Key_M:
            self.mutate(); event.accept(); return
        if event.key() == QtCore.Qt.Key.Key_S:
            self.toggle_record(); event.accept(); return
        super().keyPressEvent(event)

    def closeEvent(self, event):
        self.controller_hub.stop()
        if self.stream is not None:
            self.stream.stop(); self.stream.close()
        event.accept()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Voudontronics NERVE")
    parser.add_argument("--sample-rate", type=int, default=48000)
    parser.add_argument("--block-size", type=int, default=1024)
    parser.add_argument("--seed", default=None)
    args = parser.parse_args(argv)
    app = QtWidgets.QApplication(sys.argv)
    engine = NerveEngine(args.sample_rate, args.block_size, args.seed)
    win = NerveWindow(engine); win.show()
    raise SystemExit(app.exec())


if __name__ == "__main__":
    main()
