from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class Axon:
    sample_rate: int
    seed: int
    frequency: float = 73.0
    wander: float = 0.16
    points: int = 16
    gain: float = 0.55
    _phase: float = 0.0
    _table: np.ndarray = field(init=False, repr=False)
    _rng: np.random.Generator = field(init=False, repr=False)

    def __post_init__(self):
        self._rng = np.random.default_rng(self.seed)
        self._table = self._rng.uniform(-1, 1, self.points).astype(np.float32)

    def process(self, n: int, glia: np.ndarray | None = None) -> np.ndarray:
        inc = max(0.01, self.frequency) / self.sample_rate
        phase = self._phase + np.arange(n) * inc
        wraps = int(phase[-1]) if n else 0
        phase = np.mod(phase, 1.0)
        if wraps:
            # GENDY-like stochastic mutation: the waveform survives but its vertices wander.
            scale = self.wander * (1.0 + (float(np.mean(glia)) if glia is not None else 0.0) * 0.35)
            self._table += self._rng.normal(0.0, scale, self.points).astype(np.float32)
            np.clip(self._table, -1.0, 1.0, out=self._table)
        pos = phase * self.points
        i0 = pos.astype(np.int64) % self.points
        i1 = (i0 + 1) % self.points
        frac = (pos - np.floor(pos)).astype(np.float32)
        out = self._table[i0] * (1.0 - frac) + self._table[i1] * frac
        self._phase = float(phase[-1] + inc) % 1.0 if n else self._phase
        return (out * self.gain).astype(np.float32, copy=False)


@dataclass
class Ganglion:
    sample_rate: int
    seed: int
    density: float = 38.0
    resonance: float = 880.0
    decay: float = 0.992
    gain: float = 0.45
    _rng: np.random.Generator = field(init=False, repr=False)
    _y1: float = 0.0
    _y2: float = 0.0

    def __post_init__(self):
        self._rng = np.random.default_rng(self.seed)

    def process(self, n: int, glia: np.ndarray | None = None) -> np.ndarray:
        out = np.empty(n, dtype=np.float32)
        density = max(0.05, self.density)
        if glia is not None:
            density *= max(0.05, 1.0 + 0.6 * float(np.mean(glia)))
        p = min(0.5, density / self.sample_rate)
        w = 2.0 * np.pi * min(self.resonance, self.sample_rate * 0.45) / self.sample_rate
        c = 2.0 * np.cos(w) * self.decay
        r2 = self.decay * self.decay
        y1, y2 = self._y1, self._y2
        for i in range(n):
            impulse = 0.0
            if self._rng.random() < p:
                impulse = self._rng.choice((-1.0, 1.0)) * self._rng.uniform(0.35, 1.0)
            y = impulse + c * y1 - r2 * y2
            y2, y1 = y1, y
            out[i] = y
        self._y1, self._y2 = y1, y2
        peak = max(1.0, float(np.max(np.abs(out))))
        return (out / peak * self.gain).astype(np.float32, copy=False)


@dataclass
class Byteworm:
    sample_rate: int
    seed: int
    speed: float = 8000.0
    formula: int = 0
    gain: float = 0.38
    _t: int = 0

    def process(self, n: int, glia: np.ndarray | None = None) -> np.ndarray:
        step = max(1, int(self.speed / max(1, self.sample_rate / 8000.0)))
        t = self._t + np.arange(n, dtype=np.uint64) * np.uint64(step)
        f = int(self.formula) % 6
        with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
            if f == 0:
                v = t * ((t >> 5) | (t >> 8))
            elif f == 1:
                v = (t * (t >> 11 | t >> 8)) ^ (t >> 3)
            elif f == 2:
                v = ((t >> 6) | t | (t >> (t >> 16 & 7))) * 10
            elif f == 3:
                v = (t ^ (t >> 7) ^ (t >> 12)) * (1 + (t >> 15 & 7))
            elif f == 4:
                v = (t * 5 & (t >> 7)) | (t * 3 & (t >> 10))
            else:
                v = (t + (t >> 5) + (t >> 8)) ^ (t * (t >> 13 | 1))
        u8 = np.asarray(v & np.uint64(255), dtype=np.uint8)
        out = u8.astype(np.float32) * (2.0 / 255.0) - 1.0
        if glia is not None:
            out *= (0.78 + 0.22 * glia)
        self._t = int((int(t[-1]) + step) & ((1 << 63) - 1)) if n else self._t
        return (out * self.gain).astype(np.float32, copy=False)


@dataclass
class Knot:
    sample_rate: int
    seed: int
    a: float = 1.38
    b: float = 0.29
    rate_div: int = 4
    gain: float = 0.48
    _x: float = 0.1
    _y: float = 0.0
    _held: float = 0.0
    _counter: int = 0

    def process(self, n: int, glia: np.ndarray | None = None) -> np.ndarray:
        out = np.empty(n, dtype=np.float32)
        x, y, held, counter = self._x, self._y, self._held, self._counter
        div = max(1, int(self.rate_div))
        a = float(self.a)
        b = float(self.b)
        if glia is not None:
            a += 0.04 * float(np.mean(glia))
        for i in range(n):
            if counter <= 0:
                # Hénon-like strange-attractor update, then hold between map iterations.
                xn = 1.0 - a * x * x + y
                yn = b * x
                if not np.isfinite(xn) or abs(xn) > 4.0:
                    xn, yn = 0.1, 0.0
                x, y = xn, yn
                held = np.tanh(x * 1.4)
                counter = div
            out[i] = held
            counter -= 1
        self._x, self._y, self._held, self._counter = x, y, held, counter
        return (out * self.gain).astype(np.float32, copy=False)


class GeneratorBank:
    names = ("AXON", "GANGLION", "BYTEWORM", "KNOT")

    def __init__(self, sample_rate: int, seed: int):
        ss = np.random.SeedSequence(seed).spawn(4)
        seeds = [int(s.generate_state(1, dtype=np.uint64)[0]) for s in ss]
        self.axon = Axon(sample_rate, seeds[0])
        self.ganglion = Ganglion(sample_rate, seeds[1])
        self.byteworm = Byteworm(sample_rate, seeds[2])
        self.knot = Knot(sample_rate, seeds[3])
        self.units = [self.axon, self.ganglion, self.byteworm, self.knot]

    def process(self, n: int, glia: np.ndarray | None = None) -> list[np.ndarray]:
        return [unit.process(n, glia) for unit in self.units]
