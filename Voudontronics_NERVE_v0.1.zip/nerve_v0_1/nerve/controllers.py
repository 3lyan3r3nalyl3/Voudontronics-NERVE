from __future__ import annotations

import glob
import threading
import time
from dataclasses import dataclass, field


@dataclass
class ControllerHub:
    engine: object
    messages: list[str] = field(default_factory=list)
    _threads: list[threading.Thread] = field(default_factory=list, repr=False)
    _stop: threading.Event = field(default_factory=threading.Event, repr=False)

    def start(self) -> None:
        self._start_touchme()
        self._start_gamepad()

    def stop(self) -> None:
        self._stop.set()

    def _start_touchme(self) -> None:
        try:
            import mido
            names = mido.get_input_names()
            matches = [n for n in names if "touchme" in n.lower() or "playtronica" in n.lower()]
            if not matches:
                self.messages.append("TouchMe: not detected")
                return
            name = matches[0]
            def run():
                try:
                    with mido.open_input(name) as port:
                        self.messages.append(f"TouchMe: {name}")
                        while not self._stop.is_set():
                            for msg in port.iter_pending():
                                if msg.type == "control_change" and msg.control == 90:
                                    self.engine.set_pressure(msg.value / 127.0)
                            time.sleep(0.005)
                except Exception as exc:
                    self.messages.append(f"TouchMe error: {exc}")
            t = threading.Thread(target=run, daemon=True)
            t.start(); self._threads.append(t)
        except Exception:
            self.messages.append("TouchMe: install optional controllers dependencies")

    def _start_gamepad(self) -> None:
        try:
            from evdev import InputDevice, ecodes
            paths = glob.glob("/dev/input/by-id/*event-joystick")
            if not paths:
                self.messages.append("Gamepad: not detected")
                return
            path = paths[0]
            def run():
                try:
                    dev = InputDevice(path)
                    self.messages.append(f"Gamepad: {dev.name}")
                    for event in dev.read_loop():
                        if self._stop.is_set():
                            break
                        if event.type == ecodes.EV_ABS and event.code in (ecodes.ABS_Z, ecodes.ABS_RZ):
                            info = dev.absinfo(event.code)
                            span = max(1, info.max - info.min)
                            self.engine.set_pressure((event.value - info.min) / span)
                        elif event.type == ecodes.EV_KEY and event.value == 1:
                            if event.code in (ecodes.BTN_SOUTH, ecodes.BTN_TRIGGER):
                                self.engine.randomize()
                            elif event.code in (ecodes.BTN_EAST, ecodes.BTN_THUMB):
                                self.engine.mutate()
                except Exception as exc:
                    self.messages.append(f"Gamepad error: {exc}")
            t = threading.Thread(target=run, daemon=True)
            t.start(); self._threads.append(t)
        except Exception:
            self.messages.append("Gamepad: install optional controllers dependencies")
