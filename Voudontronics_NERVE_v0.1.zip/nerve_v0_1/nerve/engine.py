from __future__ import annotations

import json
import time
import wave
from pathlib import Path
from threading import RLock

import numpy as np

from .afferent import AfferentBank, AfferentMode
from .generators import GeneratorBank
from .modulation import GliaField, SynapseMatrix
from .util import softclip, stable_seed


class NerveEngine:
    NODE_NAMES = ("AFF1", "AFF2", "AFF3", "AFF4", "AXON", "GANGLION", "BYTEWORM", "KNOT")

    def __init__(self, sample_rate: int = 48000, block_size: int = 1024, seed: int | str | None = None):
        self.sample_rate = int(sample_rate)
        self.block_size = int(block_size)
        self.seed = stable_seed(seed if seed is not None else time.time_ns())
        self.lock = RLock()
        self.master_gain = 0.28
        self.pressure = 0.0
        self.afferents = AfferentBank(self.sample_rate, 4)
        self.generators = GeneratorBank(self.sample_rate, self.seed ^ 0xA70A)
        self.glia = GliaField(self.sample_rate, self.seed ^ 0x611A)
        self.synapse = SynapseMatrix(8, self.sample_rate, self.seed ^ 0x5A1A)
        self._recording = False
        self._recorded: list[np.ndarray] = []
        # The master seed defines the initial organism, not just its RNG stream.
        self.randomize(self.seed)

    def process(self, n: int) -> np.ndarray:
        with self.lock:
            glia = self.glia.process(n)
            # Touch pressure increases excitability but remains bounded.
            live_glia = np.clip(glia + self.pressure * 0.25, -1.0, 1.0).astype(np.float32)
            aff = self.afferents.process(n)
            gen = self.generators.process(n, live_glia)
            nodes = aff + gen
            nodes = [x * (1.0 + 0.16 * live_glia) for x in nodes]
            nodes = self.synapse.apply(nodes)
            mix = np.sum(np.vstack(nodes), axis=0) / np.float32(np.sqrt(len(nodes)))
            mix = softclip(mix * np.float32(self.master_gain), 1.35)
            stereo = np.column_stack((mix, mix)).astype(np.float32, copy=False)
            if self._recording:
                self._recorded.append(stereo.copy())
            return stereo

    def randomize(self, seed: int | str | None = None) -> int:
        with self.lock:
            if seed is None:
                # New state, immediately made reproducible by storing its seed.
                seed = time.time_ns()
            self.seed = stable_seed(seed)
            # Re-seed every stochastic subsystem from the master seed so a saved
            # NERVE seed reproduces not only parameter values but future behavior.
            self.generators = GeneratorBank(self.sample_rate, self.seed ^ 0xA70A)
            self.glia = GliaField(self.sample_rate, self.seed ^ 0x611A)
            self.synapse = SynapseMatrix(8, self.sample_rate, self.seed ^ 0x5A1A)
            rng = np.random.default_rng(self.seed)
            modes = list(AfferentMode)
            for slot in self.afferents.slots:
                slot.mode = modes[int(rng.integers(0, len(modes)))]
                slot.gain = float(rng.uniform(0.22, 0.72))
                slot.rate = float(2 ** rng.uniform(-2.0, 2.0))
                slot.bitplane = int(rng.integers(0, 8))
                slot.event_threshold = int(rng.integers(24, 180))
                slot.terrain_x_rate = float(2 ** rng.uniform(-2.5, 1.2))
                slot.terrain_y_rate = float(2 ** rng.uniform(-3.0, 0.7))
            g = self.generators
            g.axon.frequency = float(2 ** rng.uniform(4.2, 9.1))
            g.axon.wander = float(rng.uniform(0.025, 0.38))
            g.ganglion.density = float(2 ** rng.uniform(1.0, 8.0))
            g.ganglion.resonance = float(2 ** rng.uniform(6.3, 12.5))
            g.ganglion.decay = float(rng.uniform(0.965, 0.9992))
            g.byteworm.speed = float(2 ** rng.uniform(8.0, 15.0))
            g.byteworm.formula = int(rng.integers(0, 6))
            g.knot.a = float(rng.uniform(1.18, 1.43))
            g.knot.b = float(rng.uniform(0.18, 0.34))
            g.knot.rate_div = int(rng.integers(1, 33))
            self.glia.rule = int(rng.integers(0, 256))
            self.glia.hz = float(2 ** rng.uniform(0.0, 7.0))
            self.synapse.depth = float(rng.uniform(0.15, 0.70))
            self.synapse.randomize(float(rng.uniform(0.10, 0.30)))
            return self.seed

    def mutate(self, amount: float = 0.12) -> int:
        with self.lock:
            rng = np.random.default_rng(stable_seed((str(self.seed) + ":mutation:" + str(time.time_ns()))))
            self.generators.axon.wander = float(np.clip(self.generators.axon.wander * np.exp(rng.normal(0, amount)), 0.005, 0.6))
            self.generators.ganglion.density = float(np.clip(self.generators.ganglion.density * np.exp(rng.normal(0, amount)), 0.1, 700.0))
            self.generators.byteworm.speed = float(np.clip(self.generators.byteworm.speed * np.exp(rng.normal(0, amount)), 40.0, 50000.0))
            self.generators.knot.a = float(np.clip(self.generators.knot.a + rng.normal(0, amount * 0.08), 1.0, 1.45))
            active = np.argwhere(self.synapse.weights != 0)
            if active.size:
                for s, d in active[rng.choice(len(active), size=min(3, len(active)), replace=False)]:
                    self.synapse.weights[s, d] = np.float32(np.clip(self.synapse.weights[s, d] + rng.normal(0, amount), -1, 1))
            self.seed = stable_seed(str(self.seed) + ":m")
            return self.seed

    def set_pressure(self, value_0_1: float) -> None:
        with self.lock:
            self.pressure = float(np.clip(value_0_1, 0.0, 1.0))

    def start_recording(self) -> None:
        with self.lock:
            self._recorded = []
            self._recording = True

    def stop_recording(self, path: str | Path) -> Path | None:
        with self.lock:
            self._recording = False
            if not self._recorded:
                return None
            audio = np.concatenate(self._recorded, axis=0)
            self._recorded = []
        return write_wav(path, audio, self.sample_rate)

    def snapshot(self) -> dict:
        with self.lock:
            return {
                "format": "Voudontronics NERVE patch",
                "version": 1,
                "seed": int(self.seed),
                "sample_rate": self.sample_rate,
                "master_gain": self.master_gain,
                "glia": {"rule": self.glia.rule, "hz": self.glia.hz, "depth": self.glia.depth},
                "afferents": [
                    {
                        "path": str(s.path) if s.path else None,
                        "content_seed": int(s.seed),
                        "content_hash": s.content_hash,
                        "mode": s.mode.value,
                        "gain": s.gain,
                        "rate": s.rate,
                        "bitplane": s.bitplane,
                        "event_threshold": s.event_threshold,
                    }
                    for s in self.afferents.slots
                ],
                "generators": {
                    "axon": {"frequency": self.generators.axon.frequency, "wander": self.generators.axon.wander},
                    "ganglion": {"density": self.generators.ganglion.density, "resonance": self.generators.ganglion.resonance, "decay": self.generators.ganglion.decay},
                    "byteworm": {"speed": self.generators.byteworm.speed, "formula": self.generators.byteworm.formula},
                    "knot": {"a": self.generators.knot.a, "b": self.generators.knot.b, "rate_div": self.generators.knot.rate_div},
                },
                "synapse": {
                    "depth": self.synapse.depth,
                    "weights": self.synapse.weights.tolist(),
                    "hold_samples": self.synapse.hold_samples.tolist(),
                },
            }

    def save_patch(self, path: str | Path) -> Path:
        path = Path(path)
        path.write_text(json.dumps(self.snapshot(), indent=2), encoding="utf-8")
        return path

    def load_patch(self, path: str | Path) -> list[str]:
        """Restore a patch. Missing or changed food files become warnings, not crashes."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        warnings: list[str] = []
        with self.lock:
            self.randomize(int(data["seed"]))
            self.master_gain = float(data.get("master_gain", self.master_gain))
            gl = data.get("glia", {})
            self.glia.rule = int(gl.get("rule", self.glia.rule)) & 255
            self.glia.hz = float(gl.get("hz", self.glia.hz))
            self.glia.depth = float(gl.get("depth", self.glia.depth))
            for slot, cfg in zip(self.afferents.slots, data.get("afferents", [])):
                file_path = cfg.get("path")
                if file_path:
                    fp = Path(file_path)
                    if fp.is_file():
                        slot.load(fp)
                        expected = cfg.get("content_hash")
                        if expected and slot.content_hash != expected:
                            warnings.append(f"Changed file: {fp}")
                    else:
                        warnings.append(f"Missing file: {fp}")
                try:
                    slot.mode = AfferentMode(cfg.get("mode", slot.mode.value))
                except ValueError:
                    pass
                slot.gain = float(cfg.get("gain", slot.gain))
                slot.rate = float(cfg.get("rate", slot.rate))
                slot.bitplane = int(cfg.get("bitplane", slot.bitplane))
                slot.event_threshold = int(cfg.get("event_threshold", slot.event_threshold))
            gen = data.get("generators", {})
            ax = gen.get("axon", {}); ga = gen.get("ganglion", {})
            bw = gen.get("byteworm", {}); kn = gen.get("knot", {})
            self.generators.axon.frequency = float(ax.get("frequency", self.generators.axon.frequency))
            self.generators.axon.wander = float(ax.get("wander", self.generators.axon.wander))
            self.generators.ganglion.density = float(ga.get("density", self.generators.ganglion.density))
            self.generators.ganglion.resonance = float(ga.get("resonance", self.generators.ganglion.resonance))
            self.generators.ganglion.decay = float(ga.get("decay", self.generators.ganglion.decay))
            self.generators.byteworm.speed = float(bw.get("speed", self.generators.byteworm.speed))
            self.generators.byteworm.formula = int(bw.get("formula", self.generators.byteworm.formula))
            self.generators.knot.a = float(kn.get("a", self.generators.knot.a))
            self.generators.knot.b = float(kn.get("b", self.generators.knot.b))
            self.generators.knot.rate_div = int(kn.get("rate_div", self.generators.knot.rate_div))
            sy = data.get("synapse", {})
            self.synapse.depth = float(sy.get("depth", self.synapse.depth))
            if "weights" in sy:
                arr = np.asarray(sy["weights"], dtype=np.float32)
                if arr.shape == self.synapse.weights.shape:
                    self.synapse.weights[:] = arr
            if "hold_samples" in sy:
                arr = np.asarray(sy["hold_samples"], dtype=np.int32)
                if arr.shape == self.synapse.hold_samples.shape:
                    self.synapse.hold_samples[:] = arr
        return warnings


def write_wav(path: str | Path, audio: np.ndarray, sample_rate: int) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pcm = np.clip(audio, -1.0, 1.0)
    pcm = (pcm * 32767.0).astype("<i2")
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(2 if pcm.ndim == 2 else 1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(pcm.tobytes())
    return path
