from __future__ import annotations

import math
import wave
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from threading import RLock

import numpy as np

from .util import bipolar_u8, file_hash, stable_seed


class AfferentMode(str, Enum):
    RAW = "RAW BYTE"
    BITPLANE = "BITPLANE"
    TERRAIN = "TERRAIN"
    EVENT = "EVENT"
    AUDIO = "AUDIO"


@dataclass
class AfferentSlot:
    sample_rate: int
    mode: AfferentMode = AfferentMode.RAW
    gain: float = 0.55
    rate: float = 1.0
    bitplane: int = 0
    event_threshold: int = 72
    terrain_x_rate: float = 0.37
    terrain_y_rate: float = 0.113
    enabled: bool = True
    path: Path | None = None
    seed: int = 0
    content_hash: str = ""
    _bytes: np.ndarray | None = field(default=None, repr=False)
    _audio: np.ndarray | None = field(default=None, repr=False)
    _terrain: np.ndarray | None = field(default=None, repr=False)
    _cursor: float = field(default=0.0, repr=False)
    _terrain_phase: float = field(default=0.0, repr=False)
    _event_env: float = field(default=0.0, repr=False)
    _lock: RLock = field(default_factory=RLock, repr=False)

    @property
    def label(self) -> str:
        return self.path.name if self.path else "— EMPTY —"

    def load(self, path: str | Path) -> None:
        p = Path(path).expanduser().resolve()
        if not p.is_file():
            raise FileNotFoundError(p)
        # memmap keeps NERVE genuinely omnivorous without copying giant files.
        raw = np.memmap(p, dtype=np.uint8, mode="r")
        if raw.size == 0:
            raise ValueError("NERVE cannot digest an empty file.")
        with self._lock:
            self.path = p
            self._bytes = raw
            self.content_hash = file_hash(p)
            self.seed = stable_seed(bytes.fromhex(self.content_hash))
            self._cursor = 0.0
            self._terrain_phase = 0.0
            self._event_env = 0.0
            self._terrain = self._build_terrain(raw)
            self._audio = self._try_load_wav(p)

    def _build_terrain(self, raw: np.ndarray, side: int = 256) -> np.ndarray:
        target = side * side
        if raw.size >= target:
            idx = np.linspace(0, raw.size - 1, target, dtype=np.int64)
            tex = np.asarray(raw[idx], dtype=np.uint8)
        else:
            reps = int(math.ceil(target / raw.size))
            tex = np.tile(np.asarray(raw), reps)[:target]
        return bipolar_u8(tex).reshape(side, side)

    def _try_load_wav(self, path: Path) -> np.ndarray | None:
        if path.suffix.lower() not in {".wav", ".wave"}:
            return None
        try:
            with wave.open(str(path), "rb") as wf:
                channels = wf.getnchannels()
                width = wf.getsampwidth()
                frames = wf.getnframes()
                rate = wf.getframerate()
                data = wf.readframes(frames)
            if width == 1:
                x = np.frombuffer(data, np.uint8).astype(np.float32)
                x = (x - 128.0) / 128.0
            elif width == 2:
                x = np.frombuffer(data, "<i2").astype(np.float32) / 32768.0
            elif width == 4:
                x = np.frombuffer(data, "<i4").astype(np.float32) / 2147483648.0
            else:
                return None
            if channels > 1:
                x = x.reshape(-1, channels).mean(axis=1)
            if rate != self.sample_rate and x.size > 1:
                out_n = max(1, int(round(x.size * self.sample_rate / rate)))
                xp = np.linspace(0.0, 1.0, x.size, endpoint=False)
                xq = np.linspace(0.0, 1.0, out_n, endpoint=False)
                x = np.interp(xq, xp, x).astype(np.float32)
            return np.asarray(x, dtype=np.float32)
        except Exception:
            return None

    def process(self, n: int) -> np.ndarray:
        with self._lock:
            if not self.enabled or self._bytes is None:
                return np.zeros(n, dtype=np.float32)
            if self.mode == AfferentMode.RAW:
                y = self._raw(n)
            elif self.mode == AfferentMode.BITPLANE:
                y = self._bitplane(n)
            elif self.mode == AfferentMode.TERRAIN:
                y = self._terrain_scan(n)
            elif self.mode == AfferentMode.EVENT:
                y = self._events(n)
            else:
                y = self._audio_mode(n)
            return (y * np.float32(self.gain)).astype(np.float32, copy=False)

    def _indices(self, n: int, length: int) -> np.ndarray:
        step = max(0.001, float(self.rate))
        idx = (self._cursor + np.arange(n, dtype=np.float64) * step).astype(np.int64) % length
        self._cursor = (self._cursor + n * step) % length
        return idx

    def _raw(self, n: int) -> np.ndarray:
        assert self._bytes is not None
        return bipolar_u8(np.asarray(self._bytes[self._indices(n, self._bytes.size)]))

    def _bitplane(self, n: int) -> np.ndarray:
        assert self._bytes is not None
        b = np.asarray(self._bytes[self._indices(n, self._bytes.size)], dtype=np.uint8)
        bits = (b >> int(self.bitplane % 8)) & 1
        return bits.astype(np.float32) * 2.0 - 1.0

    def _terrain_scan(self, n: int) -> np.ndarray:
        assert self._terrain is not None
        side = self._terrain.shape[0]
        t = self._terrain_phase + np.arange(n, dtype=np.float64) / self.sample_rate
        # Two incommensurate trajectories through a 2-D byte landscape.
        xf = (0.5 + 0.49 * np.sin(2 * np.pi * self.terrain_x_rate * t)) * (side - 1)
        yf = (0.5 + 0.49 * np.sin(2 * np.pi * self.terrain_y_rate * t + 1.234)) * (side - 1)
        xi = xf.astype(np.int64)
        yi = yf.astype(np.int64)
        self._terrain_phase = float(t[-1] + 1.0 / self.sample_rate) if n else self._terrain_phase
        return self._terrain[yi, xi].astype(np.float32, copy=False)

    def _events(self, n: int) -> np.ndarray:
        assert self._bytes is not None
        idx = self._indices(n + 1, self._bytes.size)
        b = np.asarray(self._bytes[idx], dtype=np.int16)
        delta = np.abs(np.diff(b))
        trig = delta >= int(self.event_threshold)
        out = np.empty(n, dtype=np.float32)
        env = float(self._event_env)
        decay = 0.965
        sign = 1.0
        for i in range(n):
            if trig[i]:
                env = 1.0
                sign = -sign if (int(b[i]) & 1) else sign
            out[i] = env * sign
            env *= decay
        self._event_env = env
        return out

    def _audio_mode(self, n: int) -> np.ndarray:
        if self._audio is None or self._audio.size == 0:
            return self._raw(n)
        idx = self._indices(n, self._audio.size)
        return np.asarray(self._audio[idx], dtype=np.float32)


class AfferentBank:
    def __init__(self, sample_rate: int, count: int = 4):
        self.slots = [AfferentSlot(sample_rate) for _ in range(count)]

    def process(self, n: int) -> list[np.ndarray]:
        return [slot.process(n) for slot in self.slots]
