from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class GliaField:
    """A tiny cellular automaton that produces a global living modulation field."""

    sample_rate: int
    seed: int
    cells: int = 64
    hz: float = 23.0
    depth: float = 0.35

    def __post_init__(self):
        self.rng = np.random.default_rng(self.seed)
        self.state = self.rng.integers(0, 2, self.cells, dtype=np.uint8)
        self.rule = int(self.rng.integers(0, 256))
        self.counter = 0
        self.current = 0.0

    def randomize_rule(self, rule: int | None = None) -> None:
        self.rule = int(self.rng.integers(0, 256) if rule is None else rule) & 255
        self.state[:] = self.rng.integers(0, 2, self.cells, dtype=np.uint8)

    def _step(self) -> float:
        left = np.roll(self.state, 1)
        right = np.roll(self.state, -1)
        code = (left << 2) | (self.state << 1) | right
        self.state = ((self.rule >> code) & 1).astype(np.uint8)
        density = float(np.mean(self.state))
        edges = float(np.mean(self.state != np.roll(self.state, 1)))
        return np.clip((density - 0.5) * 1.4 + (edges - 0.5) * 0.6, -1.0, 1.0)

    def process(self, n: int) -> np.ndarray:
        out = np.empty(n, dtype=np.float32)
        period = max(1, int(self.sample_rate / max(0.1, self.hz)))
        for i in range(n):
            if self.counter <= 0:
                self.current = self._step()
                self.counter = period
            out[i] = self.current * self.depth
            self.counter -= 1
        return out


class SynapseMatrix:
    """Sparse signal-to-signal modulation with optional per-connection sample+hold."""

    def __init__(self, nodes: int, sample_rate: int, seed: int):
        self.nodes = nodes
        self.sample_rate = sample_rate
        self.rng = np.random.default_rng(seed)
        self.weights = np.zeros((nodes, nodes), dtype=np.float32)
        self.hold_samples = np.zeros((nodes, nodes), dtype=np.int32)
        self._held = np.zeros((nodes, nodes), dtype=np.float32)
        self._count = np.zeros((nodes, nodes), dtype=np.int32)
        self.depth = 0.42
        self.randomize()

    def randomize(self, density: float = 0.18) -> None:
        self.weights.fill(0.0)
        self.hold_samples.fill(0)
        mask = self.rng.random((self.nodes, self.nodes)) < density
        np.fill_diagonal(mask, False)
        self.weights[mask] = self.rng.uniform(-0.9, 0.9, np.count_nonzero(mask))
        # Roughly half of active synapses use S&H; hold period 2 ms .. 250 ms.
        sh = mask & (self.rng.random((self.nodes, self.nodes)) < 0.5)
        if np.any(sh):
            lo, hi = max(1, int(self.sample_rate * 0.002)), int(self.sample_rate * 0.250)
            self.hold_samples[sh] = self.rng.integers(lo, hi + 1, np.count_nonzero(sh))
        self._held.fill(0.0)
        self._count.fill(0)

    def _held_signal(self, src: np.ndarray, s: int, d: int) -> np.ndarray:
        period = int(self.hold_samples[s, d])
        if period <= 0:
            return src
        out = np.empty_like(src)
        held = float(self._held[s, d])
        count = int(self._count[s, d])
        for i, value in enumerate(src):
            if count <= 0:
                held = float(value)
                count = period
            out[i] = held
            count -= 1
        self._held[s, d] = held
        self._count[s, d] = count
        return out

    def apply(self, sources: list[np.ndarray]) -> list[np.ndarray]:
        if not sources:
            return []
        n = sources[0].size
        result: list[np.ndarray] = []
        for d in range(self.nodes):
            mod = np.zeros(n, dtype=np.float32)
            norm = 0.0
            for s in range(self.nodes):
                w = float(self.weights[s, d])
                if w == 0.0:
                    continue
                mod += self._held_signal(sources[s], s, d) * np.float32(w)
                norm += abs(w)
            if norm > 0:
                mod /= np.float32(norm)
            # Synapse alters local transfer function instead of simply adding another bus.
            y = np.tanh(sources[d] * (1.0 + self.depth * mod) + 0.20 * self.depth * mod)
            result.append(y.astype(np.float32, copy=False))
        return result
