# NERVE — constitutional design notes

## Identity

NERVE is not a virtual analogue synthesizer. It is an **omnivorous transduction instrument**: digital information becomes signal, event, topology, modulation, probability and control.

The core ontology is intentionally small:

- **4 AFFERENTS** — things coming into the nervous system.
- **4 GENERATORS** — AXON, GANGLION, BYTEWORM, KNOT.
- **GLIA** — distributed cellular modulation weather.
- **SYNAPSE** — relationships between nodes; S&H is a property of a relationship, not an oscillator.
- **SEED** — reproducible identity/genealogy.

## AFFERENTS

Every non-empty file is valid food. NERVE never executes it.

Universal v0.1 interpretations:

1. **RAW BYTE** — bytes become bipolar amplitudes.
2. **BITPLANE** — one bit plane becomes a binary signal.
3. **TERRAIN** — sampled file bytes become a 2-D surface traversed by coupled trajectories.
4. **EVENT** — abrupt byte transitions become decaying impulses.
5. **AUDIO** — known WAV data is decoded as audio; unknown formats fall back to RAW rather than being rejected.

Later analyzers (TEXT, IMAGE, ARCHIVE, STRUCTURE) must sit above this universal layer, never replace it.

## GENERATORS

### AXON
Probability becomes waveform. A small breakpoint waveform persists through time while its vertices perform bounded stochastic walks. It should eventually expose selectable distributions, correlation and mutation geometry.

### GANGLION
Events become excitation. A point process creates sparse impulses which excite resonant state. Future versions should add refractory periods, clustered spikes, inhibitory populations and coupled ganglia.

### BYTEWORM
Computation becomes sound. Integer overflow, bit shifts, XOR/OR/AND and small algorithmic expressions produce signal. Future versions should allow safe expression graphs rather than arbitrary executable code.

### KNOT
Nonlinear dynamics become signal. v0.1 uses a Hénon-like map with held iterations. Future versions may include coupled maps and attractor morphing, but should resist becoming a generic chaos-algorithm catalogue.

## GLIA

GLIA belongs everywhere without becoming another audible oscillator. v0.1 uses an elementary cellular automaton and derives a bounded field from density and edge activity. Later GLIA may become local: clusters of synapses could have their own cellular field.

Possible future operations:

- change synaptic probability rather than amplitude;
- change S&H clocks;
- open/close groups of connections;
- alter mutation rates;
- create slow spatial/metabolic waves through the network.

## SYNAPSE

SYNAPSE is the instrument's deepest long-term idea.

A connection eventually has:

- source node;
- destination node;
- weight;
- operation;
- clock / hold behavior;
- local state;
- optional GLIA sensitivity.

Reserved operations:

`CONTINUOUS`, `S&H`, `GATE`, `CLOCK`, `EXCITE`, `INDEX`, `WARP`, `MASK`, `XOR`, `FREEZE`.

v0.1 implements continuous modulation and per-connection S&H. The routing is deliberately sparse.

## RANDOMNESS / GENEALOGY

- **SPACE / RANDOMIZE**: replace the organism with a new reproducible state.
- **M / MUTATE**: make a local change while retaining ancestry.
- A master seed controls stochastic subsystems.
- Food files have BLAKE2b-256 content identities.
- Patches preserve both the seed and identities of what they ate.

A future **BREED** operation could combine two patches structurally without pretending that parameter interpolation is biological reproduction.

## HUMAN CONTROL

### Playtronica TouchMe
CC90 is treated as **NERVE PRESSURE**. Pressure is an abstract excitability dimension, not hardwired to volume/filter cutoff.

### Generic gamepad
v0.1 maps trigger-like axes to pressure and face buttons to randomize/mutate. Future mapping should make joysticks navigate data terrain and synaptic space.

## FX / plugin philosophy

NERVE should not waste its native code recreating commodity chorus/reverb/delay collections. External Linux plugins and Windows plugins via Linux bridges belong outside the synthesis ontology.

Native future effects should be specifically NERVE-like: event delays, topology resonators, state freeze, data-derived convolution/response structures, synaptic diffusion.

## Python → C++ boundary

Do not rewrite for prestige. Move code when profiling justifies it.

Likely first C++ candidates:

1. dense SYNAPSE + S&H processing;
2. GANGLION point-process/resonator loops;
3. KNOT nonlinear iteration;
4. future large GLIA fields;
5. interpolation and multichannel spatial processing.

Python remains excellent for UI, ingestion, patch logic, experiments, controllers and offline analysis. A future C++ realtime callback must never call back into Python.

## Preserved future organs

These are explicitly *not discarded*:

- **PULSAR** — microsound/pulse populations;
- **SOMA** — excitable-medium model;
- **RATIONAL** — prime/integer temporal lattice;
- **MORPHOGEN** — recursively growing signal/rule system;
- **SHIFT** — feedback shift-register organism;
- **TERRAIN as generator** — currently represented inside AFFERENT interpretation;
- graph-walking / Markov **SYNAPSE** variants.

They remain candidates for 1.x once the original eight-node organism has proven itself musically.
